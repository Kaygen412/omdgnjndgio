<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$x=3;
$y=5;

print ("$x + $y = ");
print $x+$y;
print ("<br><br>");

print ("$x +-$y = ");
print $x-$y;
print ("<br><br>");

print ("$x * $y : $y = ");
print $x*$y/$y;
print ("<br><br>");

print ("($x + $y) : 2 = ");
print ($x+$y)/2;
print ("<br><br>");

print ("$x + $y : 2 = ");
print $x+$y/2;
print ("<br><br>");
?>
</body>
</html>