<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$VarName="Значение переменной";

echo "1. Текст<br>$VarName<br><br>";
echo "2. Текст<br>$VarName<br><br>";
echo "3. Текст".$VarName. "(Конкатенация)<br><br>";
print ("4. Текст <br><font color=\"red\">$VarName</font><br><br>");
print ("5. Текст <br>$VarName");
//2. Работа с текстом 
?>
</body>
</html>