<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Результаты заказа</title>
</head>
<body>
<h2>Результаты заказа</h2>
<?php
echo "<p><font color=\"maroon\"><b>Заказ обработан</b></font><br><br>";
?>
</body>
</html>
