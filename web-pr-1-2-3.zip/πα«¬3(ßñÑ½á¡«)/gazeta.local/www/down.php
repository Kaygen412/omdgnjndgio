<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="CSS/style.css" rel="stylesheet" type="text/css">
    <title>Из первых рук</title>
</head>
<body bgcolor="#ccc" topmargin="0">
    <table align="center" border="0" background="image/fon.jpg" width="800" cellpadding="2">

        <tr>
            <td colspan="3" height="200">
                <img src="image/logo.gif">
            </td>
        </tr>

        <tr>
            <td colspan="3" bgcolor="#ff1e26" align="center" height="40">
                <font size="6" face="Monotype Corsiva">
                    главная - новости - статьи - рубрики - партнерам
                </font>
            </td>
        </tr>
		
        <tr>
            <td width="180" valign="top">
                <div class="text">
                    Здесь будет панель навигации
                </div>
            </td>
            <td valign="top">
                <font class="BText">ГЛАВНАЯ СТРАНИЦА</font><br>
            </td>
            <td width="170" valign="top">
                <object width="140" height="300" id="banner">
                    <param name="movie" value="flash/banner.swf">
                    <embed src="flash/banner.swf" width="140" height="300"></embed>
                </object>
            </td>
        </tr>
    </table>
</body>
</html>