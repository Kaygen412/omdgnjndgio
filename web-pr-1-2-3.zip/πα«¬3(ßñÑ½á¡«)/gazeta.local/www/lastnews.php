<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Последние новости</font><br> 
<font class="Mtext">За последнюю неделю...</font>
<?php require ('down.php') ?>