<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Список рубрик</font><br> 
<font class="Mtext">1...<br>2...<br>3...</font>
<?php require ('down.php') ?>