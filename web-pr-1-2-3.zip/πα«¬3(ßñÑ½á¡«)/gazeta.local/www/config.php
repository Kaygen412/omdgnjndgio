<?
$but1 = '<a href="index.php?t1=1">Главная</a><br>';

$but2 = '<a href="news.php?t1=2">Новости</a><br>';
$but2_1 = '<ul class="submenu"><a href="hotnews.php?t1=2"><li>Горячие новости</a></li><br>';
$but2_2 = '<a href="lastnews.php?t1=2"><li>Последние новости</a></ul>';

$but3 = '<a href="stats.php?t1=3">Статьи</a><br>';
$but3_1 = '<ul class="submenu"><a href="zakaz.php?t1=3"><li>Заказать статью</a></li><br>';
$but3_2 = '<a href="top10.php?t1=3"><li>ТОП 10</a></ul>';

$but4 = '<a href="rubriks.php?t1=4">Рубрики</a><br>';

$but5 = '<a href="partners.php?t1=5">Партнерам</a><br>';
?>