<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Разделы новостей</font><br>
<?php require ('down.php') ?>