<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Заказ статьи</font><br> 
<font class="Mtext">...</font>
<?php require ('down.php') ?>