<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Информация партерам</font><br> 
<font class="Mtext">текст...</font>
<?php require ('down.php') ?>