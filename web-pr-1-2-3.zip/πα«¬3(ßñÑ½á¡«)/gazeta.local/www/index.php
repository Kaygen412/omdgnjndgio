<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">ГЛАВНАЯ СТРАНИЦА</font><br>
<?php require ('down.php') ?>