<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">Список статей за месяц...</font>
<?php require ('down.php') ?>