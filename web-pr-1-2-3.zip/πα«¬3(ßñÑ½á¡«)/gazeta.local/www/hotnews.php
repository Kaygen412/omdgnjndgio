<?php require ('top.php') ?>
<?php require ('menu.php') ?>
<?php require ('endmenu.php') ?>
<font class="Btext">"Горячие" новости</font><br> 
<font class="Mtext">Буквально сегодня произошло...</font>
<?php require ('down.php') ?>