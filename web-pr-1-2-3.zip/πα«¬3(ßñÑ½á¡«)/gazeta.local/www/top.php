<a href="news.php?t1=2">новости</a> -
<a href="stats.php?t1=3">статьи</a> -
<a href="rubriks.php?t1=4">рубрики</a> -
<a href="partners.php?t1=5">партнерам</a> -