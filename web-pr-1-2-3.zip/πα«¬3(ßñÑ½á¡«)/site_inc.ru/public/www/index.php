<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>Функция require</title>
</head>
<body>
    <table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0" align="center">
        <!--шапка-->
        <tr>
            <td height="120" colspan="3" bgcolor="blue">
                <?php
                    require("verh.inc");
                ?>
            </td>
        </tr>

        <!--центр-->
        <tr>
            <td width="150" valign="top" bgcolor="yellow">
                <?php
                    require("left.inc");
                ?>
            </td>
            <td><h1 align="center">Это главная страница</h1></td>
            <td width="150" valign="top" bgcolor="yellow">
                <?php
                    require("right.inc");
                ?>
            </td>
        </tr>

        <!--подвал-->
        <tr>
            <td height="80" colspan="3" bgcolor="green">
                <?php
                    require("niz.inc");
                ?>
            </td>
        </tr>
    </table>
</body>
</html>